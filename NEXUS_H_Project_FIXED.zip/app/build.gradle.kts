plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexus.h"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nexus.h"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// Shizuku is the one third-party dependency: a local, offline permission-elevation broker
// (https://github.com/RikkaApps/Shizuku-API). It talks to the Shizuku app on-device only,
// never the network, and is what lets NEXUS._H actually disable/enable other apps' icons.
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
