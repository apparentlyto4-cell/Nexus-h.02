package com.nexus.h

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

class OnboardingActivity : Activity() {
    private lateinit var container: FrameLayout
    private lateinit var progress: LinearLayout
    private val pages = ArrayList<String>()
    private var idx = 0
    private var lockType: String? = null
    private var notifDenied = false
    private val REQ_NOTIF = 11

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        pages.add("welcome")
        if (!Credentials.isSet(this)) { pages.add("locktype"); pages.add("lockcreate") }
        pages.add("gesture")
        pages.add("accessibility"); pages.add("overlay")
        if (android.os.Build.VERSION.SDK_INT >= 33) pages.add("notifications")
        pages.add("done")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
        }
        progress = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.add(progress, MATCH, dp(5), mb = 12)
        container = FrameLayout(this)
        root.add(container, MATCH, 0, 1f)
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        Session.internalNav = false
        if (pages.getOrNull(idx) in setOf("accessibility", "overlay", "notifications")) render()
    }

    private fun render() {
        progress.removeAllViews()
        for (i in pages.indices) {
            val seg = View(this).apply {
                background = glass(3, if (i <= idx) Palette.violet else Palette.glassStroke, Color.TRANSPARENT)
            }
            progress.add(seg, 0, MATCH, 1f, mr = if (i == pages.size - 1) 0 else 4)
        }
        container.removeAllViews()
        container.addView(buildPage(pages[idx]), FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun next() { if (idx < pages.size - 1) { idx++; render() } }
    private fun prev() { if (idx > 0) { idx--; render() } else finish() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = prev()

    private fun page(content: View, vararg bottom: View): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        sv.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        col.add(sv, MATCH, 0, 1f)
        for (b in bottom) col.add(b, MATCH, WRAP, mt = 8)
        return col
    }

    private fun centered(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(4), dp(16), dp(4), dp(8))
    }

    private fun buildPage(id: String): View = when (id) {
        "welcome" -> {
            val c = centered()
            c.add(circleLogo(120), WRAP, WRAP, mt = 20, mb = 20)
            c.add(tv("Welcome to NEXUS._H", 26f, Palette.text, true).apply { gravity = Gravity.CENTER }, mb = 10)
            c.add(
                tv(
                    "A private space for the apps you want to keep out of sight, protected by your own Pattern, PIN or Password.\n\n" +
                        "Setup takes about a minute. We explain every permission before asking for it. Everything stays on your phone — NEXUS._H has no Internet access at all.",
                    15f, Palette.sub
                ).apply { gravity = Gravity.CENTER }
            )
            page(c, primaryBtn("Get started") { next() })
        }
        "locktype" -> {
            val c = centered()
            c.add(tv("Choose your lock", 24f, Palette.text, true).apply { gravity = Gravity.CENTER }, mb = 6)
            c.add(tv("This protects your Hidden Apps, your settings and locked apps.", 14f, Palette.sub).apply { gravity = Gravity.CENTER }, mb = 16)
            fun option(type: String, title: String, desc: String) {
                val box = card().apply { isClickable = true; setOnClickListener { lockType = type; next() }; pressable() }
                box.addView(tv(title, 17f, Palette.text, true))
                box.add(tv(desc, 13f, Palette.sub), mt = 4)
                c.add(box, mb = 10)
            }
            option(LockType.PATTERN, "Pattern", "Connect at least 4 dots on a 3×3 grid. Fast and easy.")
            option(LockType.PIN, "PIN", "4 to 12 digits on a numeric keypad.")
            option(LockType.PASSWORD, "Password", "6 or more characters. The strongest option.")
            page(c)
        }
        "lockcreate" -> {
            val c = centered()
            val t = lockType ?: LockType.PIN
            c.add(LockCreateView(this, t) { secret ->
                Credentials.save(this, t, secret)
                toast("${LockType.title(t)} saved")
                pages.remove("locktype"); pages.remove("lockcreate")
                idx = pages.indexOf("gesture")
                render()
            }, MATCH, WRAP)
            page(c, linkBtn("Choose a different lock type") { prev() })
        }
        "gesture" -> {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.add(tv("Pick your secret gesture", 22f, Palette.text, true).apply { gravity = Gravity.CENTER }, mb = 4)
            col.add(
                tv("This gesture opens Hidden Apps (you will still enter your lock).", 13.5f, Palette.sub).apply { gravity = Gravity.CENTER },
                mb = 8
            )
            col.add(GesturePickerView(this, Store.gesture(this)) { }, MATCH, 0, 1f)
            col.add(ghostBtn("Continue") { next() }, mt = 8)
            col
        }
        "accessibility", "overlay", "notifications" -> permPage(id)
        else -> donePage()
    }

    private fun permPage(id: String): View {
        val info = permList(this).firstOrNull { it.id == id } ?: return donePage()
        val c = centered()
        c.add(tv(info.title, 23f, Palette.text, true).apply { gravity = Gravity.CENTER }, mb = 10)
        c.add(
            tv(if (info.granted) "✓ Enabled" else if (info.optional) "Optional — not enabled yet" else "Not enabled", 14f,
                if (info.granted) Palette.ok else Palette.cyan, true).apply { gravity = Gravity.CENTER }, mb = 14
        )
        val box = card()
        box.addView(tv("What it does", 13f, Palette.purple, true))
        box.add(tv(info.why, 14.5f, Palette.text), mt = 4, mb = 10)
        box.addView(tv(info.feature, 13.5f, Palette.sub))
        if (id == "accessibility") {
            box.add(
                tv(
                    "How: tap the button, find NEXUS._H in the list, turn it on and confirm. Then come back here. " +
                        "If it is greyed out on Android 13+: App info → ⋮ → “Allow restricted settings”.",
                    13f, Palette.sub
                ), mt = 10
            )
        }
        if (id == "notifications" && notifDenied && !info.granted) {
            box.add(tv("Notifications were denied. You can enable them in system settings.", 13f, Palette.cyan), mt = 10)
        }
        c.add(box)
        if (info.granted) return page(c, primaryBtn("Continue") { next() })
        val label = if (id == "notifications" && notifDenied) "Open notification settings" else info.actionLabel
        return page(
            c,
            primaryBtn(label) {
                when (id) {
                    "accessibility" -> Perms.openAccessibility(this)
                    "overlay" -> Perms.openOverlay(this)
                    "notifications" -> if (notifDenied) Perms.openNotificationSettings(this) else Perms.requestNotifications(this, REQ_NOTIF)
                }
            },
            linkBtn("Skip for now") { next() }
        )
    }

    private fun donePage(): View {
        val c = centered()
        c.add(circleLogo(88), WRAP, WRAP, mt = 8, mb = 14)
        c.add(tv("You're all set", 25f, Palette.text, true).apply { gravity = Gravity.CENTER }, mb = 6)
        c.add(tv("Here is what is available. You can fix anything later in Settings → Permission Status.", 14f, Palette.sub).apply { gravity = Gravity.CENTER }, mb = 14)
        val box = card()
        for (p in permList(this)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, dp(6)) }
            row.add(tv(p.title, 14f, Palette.text), 0, WRAP, 1f, mr = 8)
            row.addView(tv(if (p.granted) "✓ On" else "Off", 14f, if (p.granted) Palette.ok else Palette.sub, true))
            box.addView(row)
        }
        c.add(box)
        if (!Perms.accessibilityEnabled(this)) {
            c.add(
                tv("Limited mode: apps can be hidden and opened from NEXUS._H, but they are not locked when opened elsewhere until Accessibility is on.", 13f, Palette.cyan),
                mt = 12
            )
        }
        return page(c, primaryBtn("Open NEXUS._H") {
            Store.setOnboarded(this, true)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        })
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) notifDenied = true
            render()
        }
    }

}
