package com.nexus.h

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * A small overlay handle that sits on the phone's OWN home screen (any manufacturer's launcher).
 * It does not replace or redraw the home screen — it is a transparent window floating above it.
 * Performing the configured gesture on the handle opens NEXUS._H's lock screen directly.
 *
 * Android gives ordinary apps no way to receive gestures performed elsewhere on the home screen
 * (on an icon, in empty space away from the handle, etc.) — only within views the app itself owns.
 * This handle is the closest legitimate approximation: always on screen, draggable to a convenient
 * spot, and it does not block taps or swipes that happen outside its small area.
 */
class HomeGestureService : Service() {
    private var wm: WindowManager? = null
    private var view: View? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startFg()
        if (!Perms.overlay(this) || !Store.homeGesture(this)) { stopSelf(); return START_NOT_STICKY }
        if (view == null) showHandle()
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("home_gesture", "Home screen gesture handle", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, HomeGestureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "home_gesture")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("NEXUS._H gesture handle is on")
            .setContentText("Your gesture on the handle opens NEXUS._H.")
            .setOngoing(true)
            .addAction(R.drawable.ic_notif, "Hide handle", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)
    }

    private fun showHandle() {
        val ctx = this
        val frame = GestureFrame(ctx).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.parseColor("#33A78BFA"))
                setStroke(ctx.dp(1), Color.parseColor("#66A78BFA"))
            }
        }
        val dot = View(ctx).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Palette.violet)
            }
        }
        frame.addView(dot, android.widget.FrameLayout.LayoutParams(ctx.dp(10), ctx.dp(10), Gravity.CENTER))
        frame.recognizer = GestureRecognizer(ctx) { g ->
            if (g == Store.gesture(ctx)) frame.post {
                try {
                    startActivity(Intent(ctx, HiddenAppsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Throwable) {
                }
            }
        }

        val size = ctx.dp(46)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val dm = resources.displayMetrics
            when (Store.handlePos(ctx)) {
                0 -> { x = ctx.dp(10); y = ctx.dp(80) }
                1 -> { x = dm.widthPixels - size - ctx.dp(10); y = ctx.dp(80) }
                2 -> { x = ctx.dp(10); y = dm.heightPixels - size - ctx.dp(140) }
                else -> { x = dm.widthPixels - size - ctx.dp(10); y = dm.heightPixels - size - ctx.dp(140) }
            }
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        dot.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                android.view.MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    try { wm?.updateViewLayout(frame, lp) } catch (_: Throwable) {}
                }
            }
            true
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try { wm?.addView(frame, lp); view = frame } catch (_: Throwable) { stopSelf() }
    }

    override fun onDestroy() {
        try { view?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        view = null
        running = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.nexus.h.STOP_HOME_GESTURE"
        @Volatile var running = false

        fun start(c: Context) {
            if (!Store.homeGesture(c) || !Perms.overlay(c)) return
            if (running) return
            running = true
            try { c.startForegroundService(Intent(c, HomeGestureService::class.java)) } catch (_: Throwable) { running = false }
        }

        fun stop(c: Context) {
            running = false
            try { c.stopService(Intent(c, HomeGestureService::class.java)) } catch (_: Throwable) {}
        }
    }
}
