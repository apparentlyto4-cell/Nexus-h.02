package com.nexus.h

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot

enum class Gesture(val id: String, val title: String, val how: String) {
    TWO_DOUBLE_TAP(
        "two_double_tap", "Two-Finger Double Tap",
        "Tap the screen with two fingers at the same moment, then do it again right away."
    ),
    TWO_SWIPE_UP(
        "two_swipe_up", "Two-Finger Swipe Up",
        "Place two fingers side by side and slide both of them upward together, about a third of the screen."
    ),
    THREE_TAP(
        "three_tap", "Three-Finger Tap",
        "Touch the screen with three fingers at the same time and lift them quickly."
    ),
    PINCH_IN(
        "pinch_in", "Two-Finger Pinch",
        "Start with two fingers spread apart, then bring them together as if pinching something."
    ),
    TWO_HOLD(
        "two_hold", "Two-Finger Hold",
        "Press two fingers on the screen and keep them still for about one second."
    );

    companion object {
        fun byId(id: String?): Gesture = values().firstOrNull { it.id == id } ?: TWO_DOUBLE_TAP
    }
}

/**
 * Feed every MotionEvent of a view into onTouch(). Emits a Gesture only when a full, deliberate
 * multi-finger gesture is recognised. Single-finger touches (scrolling, taps, notification pulls) are ignored.
 */
class GestureRecognizer(private val ctx: Context, private val onGesture: (Gesture) -> Unit) {
    private val MAXP = 12
    private val slop = ctx.dp(18).toFloat()
    private val handler = Handler(Looper.getMainLooper())
    private val sx = FloatArray(MAXP)
    private val sy = FloatArray(MAXP)
    private val cx = FloatArray(MAXP)
    private val cy = FloatArray(MAXP)
    private val down = BooleanArray(MAXP)
    private var maxPtr = 0
    private var tMulti = 0L
    private var startDist = 0f
    private var evaluated = false
    private var lastTap = 0L

    private val holdRunnable = Runnable {
        if (!evaluated && activeCount() == 2 && maxPtr == 2 && maxMove() < slop) {
            evaluated = true
            onGesture(Gesture.TWO_HOLD)
        }
    }

    private fun reset() {
        handler.removeCallbacks(holdRunnable)
        for (i in 0 until MAXP) down[i] = false
        maxPtr = 0; evaluated = false; startDist = 0f
    }

    private fun activeCount() = down.count { it }
    private fun ids() = (0 until MAXP).filter { down[it] }

    private fun add(e: MotionEvent, index: Int) {
        val id = e.getPointerId(index)
        if (id >= MAXP) return
        down[id] = true
        sx[id] = e.getX(index); sy[id] = e.getY(index)
        cx[id] = sx[id]; cy[id] = sy[id]
    }

    private fun sync(e: MotionEvent) {
        for (i in 0 until e.pointerCount) {
            val id = e.getPointerId(i)
            if (id < MAXP && down[id]) { cx[id] = e.getX(i); cy[id] = e.getY(i) }
        }
    }

    private fun maxMove(): Float {
        var m = 0f
        for (id in ids()) m = maxOf(m, hypot(cx[id] - sx[id], cy[id] - sy[id]))
        return m
    }

    private fun dist(): Float {
        val l = ids()
        if (l.size < 2) return 0f
        return hypot(cx[l[0]] - cx[l[1]], cy[l[0]] - cy[l[1]])
    }

    fun onTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                reset()
                add(e, 0)
                maxPtr = 1
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (evaluated) return
                add(e, e.actionIndex)
                maxPtr = maxOf(maxPtr, activeCount())
                tMulti = e.eventTime
                if (activeCount() == 2) {
                    startDist = dist()
                    handler.removeCallbacks(holdRunnable)
                    handler.postDelayed(holdRunnable, 900)
                } else {
                    handler.removeCallbacks(holdRunnable)
                }
            }
            MotionEvent.ACTION_MOVE -> sync(e)
            MotionEvent.ACTION_POINTER_UP -> {
                sync(e)
                handler.removeCallbacks(holdRunnable)
                if (!evaluated && maxPtr >= 2) {
                    evaluated = true
                    evaluate(e.eventTime)
                }
                val id = e.getPointerId(e.actionIndex)
                if (id < MAXP) down[id] = false
            }
            MotionEvent.ACTION_UP -> {
                sync(e)
                if (!evaluated && maxPtr >= 2) { evaluated = true; evaluate(e.eventTime) }
                reset()
            }
            MotionEvent.ACTION_CANCEL -> reset()
        }
    }

    private fun evaluate(now: Long) {
        val l = ids()
        val n = l.size
        val dur = now - tMulti
        val move = maxMove()
        if (n >= 3) {
            if (dur <= 350 && move < slop * 1.6f) fire(Gesture.THREE_TAP)
            return
        }
        if (n != 2) return
        var avgDx = 0f; var avgDy = 0f; var minUp = Float.MAX_VALUE
        for (id in l) {
            avgDx += cx[id] - sx[id]; avgDy += cy[id] - sy[id]
            minUp = minOf(minUp, sy[id] - cy[id])
        }
        avgDx /= n; avgDy /= n
        val d1 = dist()
        when {
            dur <= 300 && move < slop * 1.6f -> {
                if (lastTap != 0L && now - lastTap <= 600) { lastTap = 0; fire(Gesture.TWO_DOUBLE_TAP) }
                else lastTap = now
            }
            -avgDy > ctx.dp(110) && minUp > ctx.dp(60) && abs(avgDx) < abs(avgDy) * 0.7f -> fire(Gesture.TWO_SWIPE_UP)
            startDist > 0 && d1 < startDist * 0.6f && startDist - d1 > ctx.dp(70) -> fire(Gesture.PINCH_IN)
        }
    }

    private fun fire(g: Gesture) { onGesture(g) }
}

/** Frame that feeds all touches into a recognizer without consuming them. */
class GestureFrame(c: Context) : FrameLayout(c) {
    var recognizer: GestureRecognizer? = null
    var gesturesEnabled = true
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (gesturesEnabled) recognizer?.onTouch(ev)
        return super.dispatchTouchEvent(ev)
    }

    // Consume touches nobody else wanted, so we keep receiving the later MOVE / POINTER events.
    override fun onTouchEvent(event: MotionEvent): Boolean = true
}

/** Looping animation that shows what a gesture looks like. */
class GestureDemoView(c: Context, private val g: Gesture) : View(c) {
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun finger(c: Canvas, x: Float, y: Float, a: Float, scale: Float = 1f) {
        if (a <= 0f) return
        val r = context.dpf(11f) * scale
        p.style = Paint.Style.FILL
        p.color = Palette.violet; p.alpha = (70 * a).toInt()
        c.drawCircle(x, y, r * 1.9f, p)
        p.color = Palette.purple; p.alpha = (255 * a).toInt()
        c.drawCircle(x, y, r, p)
    }

    private fun pulse(c: Canvas, x: Float, y: Float, k: Float) {
        // k in 0..1 : ring expanding while fading
        if (k <= 0f || k >= 1f) return
        p.style = Paint.Style.STROKE
        p.strokeWidth = context.dpf(2f)
        p.color = Palette.cyan; p.alpha = (200 * (1 - k)).toInt()
        c.drawCircle(x, y, context.dpf(12f) + context.dpf(22f) * k, p)
    }

    private fun seg(v: Float, a: Float, b: Float) = ((v - a) / (b - a)).coerceIn(0f, 1f)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = Color.WHITE; p.alpha = 14
        c.drawRoundRect(RectF(0f, 0f, w, h), context.dpf(18f), context.dpf(18f), p)
        when (g) {
            Gesture.TWO_DOUBLE_TAP -> {
                val xs = floatArrayOf(w * .38f, w * .62f); val ys = floatArrayOf(h * .55f, h * .48f)
                for (i in 0..1) {
                    val k1 = seg(t, .05f, .30f); val k2 = seg(t, .45f, .70f)
                    val vis1 = t in .05f..0.16f; val vis2 = t in .45f..0.56f
                    finger(c, xs[i], ys[i], if (vis1 || vis2) 1f else 0.25f, if (vis1 || vis2) 0.85f else 1f)
                    pulse(c, xs[i], ys[i], k1); pulse(c, xs[i], ys[i], k2)
                }
            }
            Gesture.TWO_SWIPE_UP -> {
                val k = seg(t, .1f, .7f)
                val y = h * (.78f - .5f * k)
                val a = if (t < .1f) t / .1f else if (t > .8f) (1f - t) / .2f else 1f
                for (x in floatArrayOf(w * .4f, w * .6f)) {
                    p.style = Paint.Style.STROKE; p.strokeWidth = context.dpf(3f)
                    p.color = Palette.cyan; p.alpha = (110 * a).toInt()
                    c.drawLine(x, h * .78f, x, y, p)
                    finger(c, x, y, a)
                }
            }
            Gesture.THREE_TAP -> {
                val xs = floatArrayOf(w * .3f, w * .5f, w * .7f); val ys = floatArrayOf(h * .55f, h * .45f, h * .55f)
                val k = seg(t, .1f, .45f)
                val vis = t in .1f..0.25f
                for (i in 0..2) { finger(c, xs[i], ys[i], if (vis) 1f else 0.25f, if (vis) .85f else 1f); pulse(c, xs[i], ys[i], k) }
            }
            Gesture.PINCH_IN -> {
                val k = seg(t, .15f, .7f)
                val d = (0.36f - 0.30f * k) * minOf(w, h) * 1.3f
                val cx = w / 2; val cy = h / 2
                val a = if (t < .1f) t / .1f else if (t > .85f) (1f - t) / .15f else 1f
                finger(c, cx - d * .7f, cy + d * .7f, a); finger(c, cx + d * .7f, cy - d * .7f, a)
            }
            Gesture.TWO_HOLD -> {
                val k = seg(t, .1f, .8f)
                val xs = floatArrayOf(w * .4f, w * .6f)
                for (x in xs) {
                    finger(c, x, h * .5f, 1f)
                    p.style = Paint.Style.STROKE; p.strokeWidth = context.dpf(3f)
                    p.color = Palette.cyan; p.alpha = 230
                    val r = context.dpf(24f)
                    c.drawArc(RectF(x - r, h * .5f - r, x + r, h * .5f + r), -90f, 360f * k, false, p)
                }
            }
        }
    }
}

/** Gesture list + test area + Save. Used in onboarding and in the Gesture screen. */
class GesturePickerView(c: Context, initial: Gesture, private val onSaved: (Gesture) -> Unit) : LinearLayout(c) {
    private var selected = initial
    private val cards = HashMap<Gesture, LinearLayout>()
    private val radios = HashMap<Gesture, TextView>()
    private val result = c.tv("Try the selected gesture in the box above.", 13.5f, Palette.sub).apply { gravity = Gravity.CENTER }
    private val saveBtn: TextView

    init {
        orientation = VERTICAL
        val sv = ScrollView(c).apply { overScrollMode = OVER_SCROLL_NEVER }
        val list = LinearLayout(c).apply { orientation = VERTICAL }
        list.add(
            c.tv(
                "Works inside the NEXUS._H dashboard. Android does not let an app add gestures to your phone's own home screen, " +
                    "so the original launcher stays exactly as it is.", 12.5f, Palette.sub
            ), mb = 10
        )
        for (g in Gesture.values()) list.add(buildCard(c, g), mb = 10)
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        add(sv, MATCH, 0, 1f)

        // Test area
        val test = GestureFrame(c).apply {
            background = c.glass(18, Palette.glassStrong, Palette.violet)
            addView(c.tv("Test area — try the gesture here", 14f, Palette.text, true).apply { gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(MATCH, MATCH))
            recognizer = GestureRecognizer(c) { g ->
                post {
                    if (g == selected) {
                        result.text = "✓ ${g.title} detected — this is your selected gesture."
                        result.setTextColor(Palette.ok)
                    } else {
                        result.text = "Detected: ${g.title}. Your selected gesture is ${selected.title}."
                        result.setTextColor(Palette.cyan)
                    }
                }
            }
            setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
        }
        add(test, MATCH, c.dp(96), mt = 8)
        add(result, MATCH, WRAP, mt = 6, mb = 6)
        saveBtn = c.primaryBtn("Save gesture") { save() }
        add(saveBtn)
        refresh()
    }

    private fun buildCard(c: Context, g: Gesture): LinearLayout {
        val card = LinearLayout(c).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(12), c.dp(12), c.dp(12), c.dp(12))
            isClickable = true
            setOnClickListener { selected = g; result.text = "Try the selected gesture in the box below."; result.setTextColor(Palette.sub); refresh() }
        }
        card.add(GestureDemoView(c, g), c.dp(92), c.dp(92), mr = 12)
        val col = LinearLayout(c).apply { orientation = VERTICAL }
        col.addView(c.tv(g.title, 15.5f, Palette.text, true))
        col.addView(c.tv(g.how, 12.5f, Palette.sub))
        card.add(col, 0, WRAP, 1f)
        val radio = c.tv("", 16f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        card.add(radio, c.dp(28), c.dp(28), ml = 8)
        cards[g] = card; radios[g] = radio
        return card
    }

    private fun refresh() {
        for (g in Gesture.values()) {
            val on = g == selected
            cards[g]?.background = if (on) context.glass(18, Palette.glassStrong, Palette.violet) else context.glass(18)
            val r = radios[g]!!
            r.text = if (on) "✓" else ""
            r.background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                if (on) setColor(Palette.violet) else setColor(Color.TRANSPARENT)
                setStroke(context.dp(2), if (on) Palette.violet else Palette.sub)
            }
        }
        saveBtn.text = "Save gesture"
    }

    private fun save() {
        Store.setGesture(context, selected)
        result.text = "✓ Saved: ${selected.title}"
        result.setTextColor(Palette.ok)
        saveBtn.text = "Saved ✓"
        onSaved(selected)
    }
}
