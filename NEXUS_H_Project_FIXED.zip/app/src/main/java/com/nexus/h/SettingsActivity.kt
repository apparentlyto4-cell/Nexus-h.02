package com.nexus.h

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : SecureActivity() {
    private lateinit var body: LinearLayout
    private val REQ_NOTIF = 31
    private var notifAsked = false
    private val shizukuListener = rikka.shizuku.Shizuku.OnRequestPermissionResultListener { _, grant ->
        runOnUiThread {
            toast(if (grant == PackageManager.PERMISSION_GRANTED) "Shizuku permission granted" else "Shizuku permission denied")
            Bg.executor.execute { ShizukuManager.resync(applicationContext) }
            refresh()
        }
    }

    override fun buildUi() {
        val s = Screen(this, "Settings")
        body = s.body
        setContentView(s.root)
        ShizukuManager.addPermissionListener(shizukuListener)
        refresh()
    }

    override fun onDestroy() {
        ShizukuManager.removePermissionListener(shizukuListener)
        super.onDestroy()
    }

    override fun onSecureResume() {
        Launcher.selfHeal(this)
        Bg.executor.execute { ShizukuManager.resync(applicationContext) }
        refresh()
    }

    private fun section(title: String): LinearLayout {
        body.add(tv(title.uppercase(), 12f, Palette.purple, true), mt = 14, mb = 6, ml = 4)
        val c = card(14)
        body.add(c)
        return c
    }

    private fun refresh() {
        body.removeAllViews()
        val type = Credentials.type(this)

        // ---- Security
        val sec = section("Security")
        sec.addView(navRow("Change lock type", "Currently: ${LockType.title(type)}") {
            startInternal(Intent(this, ChangeLockActivity::class.java))
        })
        sec.addView(divider())
        sec.addView(navRow("Change ${LockType.title(type)}", "Verify your current lock, then set a new one") {
            startInternal(Intent(this, ChangeLockActivity::class.java).putExtra("type", type))
        })
        sec.addView(divider())
        sec.addView(navRow("Open gesture", Store.gesture(this).title) { startInternal(Intent(this, GestureActivity::class.java)) })

        // ---- Hidden apps & App Lock
        val apps = section("Hidden apps & App Lock")
        apps.addView(navRow("Manage hidden apps", "${Store.hidden(this).size} hidden, ${Store.locked(this).size} locked") {
            startInternal(Intent(this, HiddenAppsActivity::class.java))
        })
        apps.addView(divider())
        apps.addView(switchRow("Enforce app locks", "Ask for your lock when a locked app is opened.", Store.lockEnforce(this)) {
            Store.setLockEnforce(this, it)
        })
        val acc = Perms.accessibilityEnabled(this)
        apps.add(
            tv(if (acc) "✓ Accessibility service is on — locks can be enforced." else "Accessibility is OFF — locks are not enforced yet.",
                13f, if (acc) Palette.ok else Palette.cyan, true), mt = 4
        )
        if (!acc) apps.add(ghostBtn("Turn on Accessibility") { Perms.openAccessibility(this) }, mt = 8)

        // ---- Icon visibility (three separate things)
        val lm = section("Hiding & protection")
        lm.addView(tv("Your phone's original launcher is never changed by NEXUS._H.", 15f, Palette.text, true))
        lm.add(
            tv(
                "• Hidden in NEXUS._H: the app is kept in your protected list here.\n" +
                    "• Icon in your phone's launcher: NEXUS._H cannot remove it. Use your phone maker's own “Hide apps” feature.\n" +
                    "• Locked: NEXUS._H asks for your lock when the app is opened (needs Accessibility).",
                13f, Palette.sub
            ), mt = 6
        )
        lm.add(ghostBtn("How to hide icons in my launcher") {
            AlertDialog.Builder(this).setTitle("Hide icons in your launcher").setMessage(HideInfo.launcherSteps()).setPositiveButton("OK", null).show()
        }, mt = 10)
        lm.addView(divider())
        val tile = Store.tileAdded(this)
        val hiddenIcon = Launcher.isIconHidden(this)
        lm.addView(switchRow(
            "Hide NEXUS._H's own icon",
            if (tile || hiddenIcon) "Removes it from app lists. Re-open it from the NEXUS._H Quick Settings tile." else "First add the NEXUS._H Quick Settings tile below, so you can always open the app again.",
            hiddenIcon, tile || hiddenIcon
        ) { on ->
            if (on) confirmHideSelf() else { Launcher.setIconHidden(this, false); Store.setHideSelf(this, false); toast("Icon restored") }
        })
        lm.add(
            tv(if (tile) "✓ Quick Settings tile is in your panel — this is your way back in." else "Quick Settings tile: not added yet.",
                13f, if (tile) Palette.ok else Palette.cyan, true), mt = 4
        )
        if (!tile) {
            lm.add(tv("Swipe down twice from the top → tap the pencil / edit icon → drag the NEXUS._H tile into your panel.", 12.5f, Palette.sub), mt = 4)
            if (android.os.Build.VERSION.SDK_INT >= 33) lm.add(ghostBtn("Add Quick Settings tile") { requestTile() }, mt = 8)
        }

        // ---- Really hide icons (Shizuku)
        val sh = section("Really hide icons (Shizuku)")
        sh.addView(tv("Shizuku is a free, separate app that lets NEXUS._H remove an app's icon from every launcher on this phone, not just NEXUS._H's own list.", 13f, Palette.sub))
        when {
            !ShizukuManager.installed() -> {
                sh.add(tv("Shizuku app not found", 14f, Palette.cyan, true), mt = 10)
                sh.add(tv("Install the free “Shizuku” app from the Play Store, then come back here.", 13f, Palette.sub), mt = 2)
            }
            !ShizukuManager.running() -> {
                sh.add(tv("Shizuku is not running", 14f, Palette.cyan, true), mt = 10)
                sh.add(tv("Open the Shizuku app and start its service (it explains how), then come back here.", 13f, Palette.sub), mt = 2)
            }
            !ShizukuManager.hasPermission() -> {
                sh.add(tv("Permission needed", 14f, Palette.cyan, true), mt = 10)
                sh.add(ghostBtn("Grant Shizuku permission") { ShizukuManager.requestPermission() }, mt = 8)
            }
            else -> sh.add(tv("✓ Shizuku ready.", 14f, Palette.ok, true), mt = 10)
        }
        val reallyCount = Store.reallyHidden(this).size
        sh.add(
            tv(
                if (reallyCount == 0) "No apps are set to be really hidden yet. Choose this per app from the Add apps screen, or long-press an app in Hidden apps."
                else "$reallyCount app${if (reallyCount == 1) "" else "s"} set to be really hidden. Shizuku must stay running for this to stay in effect; it must be turned on again after the phone restarts.",
                12.5f, Palette.sub
            ), mt = 10
        )

        // ---- Home screen gesture handle
        val hg = section("Gesture handle on Home screen")
        hg.addView(tv("A small, draggable handle that sits on your phone's own Home screen. Your home screen itself is never changed — this is an overlay on top of it.", 13f, Palette.sub))
        hg.add(switchRow("Show handle on Home screen", "Perform your open gesture on it to unlock Hidden apps without opening NEXUS._H first. Needs “Display over other apps”.", Store.homeGesture(this)) { on ->
            if (on && !Perms.overlay(this)) { Store.setHomeGesture(this, false); Perms.openOverlay(this); toast("Allow “Display over other apps”, then switch this on again."); refresh() }
            else { Store.setHomeGesture(this, on); if (on) HomeGestureService.start(this) else HomeGestureService.stop(this) }
        }, mt = 10)
        if (Store.homeGesture(this)) {
            val hnames = listOf("Top-left", "Top-right", "Bottom-left", "Bottom-right")
            val hr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in hnames.indices) hr.add(chip(hnames[i], Store.handlePos(this) == i) { Store.setHandlePos(this, i); HomeGestureService.stop(this); HomeGestureService.start(this); refresh() }, 0, WRAP, 1f, mr = if (i < 3) 6 else 0)
            hg.add(hr, mt = 8)
        }
        hg.add(tv("Note: Android stops background overlays after a restart or a long period unused on some phones; if the handle disappears, switch this off and back on.", 12f, Palette.sub), mt = 8)

        // ---- Quick exit
        val qe = section("Clean & Exit button")
        qe.addView(tv("Position on the Hidden apps screen", 14f, Palette.text, true))
        val names = listOf("Top-left", "Bottom-left", "Bottom-center", "Bottom-right")
        // two rows of two so labels never clip on small screens
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in names.indices) {
            val ch = chip(names[i], Store.qePos(this) == i) { Store.setQePos(this, i); refresh() }
            (if (i < 2) r1 else r2).add(ch, 0, WRAP, 1f, mr = if (i % 2 == 0) 8 else 0)
        }
        qe.add(r1, mt = 8); qe.add(r2, mt = 8)
        qe.addView(divider())
        qe.addView(switchRow("Floating button over other apps", "Optional. Needs “Display over other apps”. Appears after you open Hidden apps.", Store.floating(this)) { on ->
            if (on && !Perms.overlay(this)) { Store.setFloating(this, false); Perms.openOverlay(this); toast("Allow “Display over other apps”, then switch this on again."); refresh() }
            else { Store.setFloating(this, on); if (!on) QuickExitService.stop(this) }
        })
        val last = Store.lastClean(this).split("|")
        if (last.size == 2) {
            val kb = (last[1].toLongOrNull() ?: 0L) / 1024
            qe.add(tv("Last cleanup: removed $kb KB of NEXUS._H's own temporary files. Other apps' caches are never touched.", 12.5f, Palette.sub), mt = 6)
        } else {
            qe.add(tv("Clean & Exit clears only NEXUS._H's own temporary files, removes NEXUS._H from Recents and returns Home right away.", 12.5f, Palette.sub), mt = 6)
        }

        // ---- Permission status
        val ps = section("Permission status")
        for (p in permList(this)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            top.add(tv(p.title, 14f, Palette.text, true), 0, WRAP, 1f, mr = 8)
            top.addView(tv(if (p.granted) "✓ On" else "Needs attention", 13f, if (p.granted) Palette.ok else Palette.cyan, true))
            row.addView(top)
            row.add(tv(p.feature, 12.5f, Palette.sub), mt = 2)
            if (!p.granted) row.add(ghostBtn(p.actionLabel) { fix(p) }, mt = 8)
            ps.addView(row)
        }

        // ---- Help
        val help = section("Help")
        help.addView(navRow("Recovery & troubleshooting", "Forgot lock, missing icon, battery settings") {
            startActivity(Intent(this, RecoveryActivity::class.java))
        })
        help.addView(divider())
        help.add(tv("NEXUS._H has no Internet permission, no analytics and no accounts. Everything stays on this phone.", 12.5f, Palette.sub), mt = 6)
        body.add(tv("NEXUS._H 1.0.0", 12f, Palette.sub).apply { gravity = android.view.Gravity.CENTER }, mt = 18, mb = 8)
    }

    private fun fix(p: PermInfo) {
        when (p.id) {
            "accessibility" -> Perms.openAccessibility(this)
            "overlay" -> Perms.openOverlay(this)
            "notifications" -> {
                if (!notifAsked) { notifAsked = true; Perms.requestNotifications(this, REQ_NOTIF) }
                else Perms.openNotificationSettings(this)
            }
        }
    }

    private fun requestTile() {
        try {
            val sbm = getSystemService(android.app.StatusBarManager::class.java)
            sbm.requestAddTileService(
                android.content.ComponentName(this, NexusTileService::class.java), getString(R.string.app_name),
                android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_notif), mainExecutor
            ) { _ -> refresh() }
        } catch (t: Throwable) {
            toast("Please add the tile manually from Quick Settings → edit.")
        }
    }

    private fun confirmHideSelf() {
        AlertDialog.Builder(this).setTitle("Hide NEXUS._H's icon?")
            .setMessage("NEXUS._H will disappear from your launcher and app lists. To open it again, use the NEXUS._H tile in Quick Settings (swipe down twice from the top).\n\nIf you remove that tile, the icon comes back automatically. Dialing *#*#6394#*#* also works on some phones.")
            .setPositiveButton("Hide icon") { _, _ ->
                Launcher.setIconHidden(this, true); Store.setHideSelf(this, true); toast("Icon hidden"); refresh()
            }
            .setNegativeButton("Cancel") { _, _ -> refresh() }
            .setOnCancelListener { refresh() }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) toast("Notifications are still off.")
            refresh()
        }
    }
}
