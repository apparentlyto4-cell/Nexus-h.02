package com.nexus.h

class GestureActivity : SecureActivity() {
    override fun buildUi() {
        val s = Screen(this, "Open gesture", scroll = false)
        s.body.add(GesturePickerView(this, Store.gesture(this)) { }, MATCH, 0, 1f)
        setContentView(s.root)
    }
}
