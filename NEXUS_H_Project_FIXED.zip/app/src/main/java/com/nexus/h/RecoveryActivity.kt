package com.nexus.h

import android.app.Activity
import android.os.Bundle
import android.view.View

class RecoveryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val s = Screen(this, "Recovery & help")
        fun section(title: String, text: String) {
            val c = card()
            c.addView(tv(title, 16f, Palette.text, true))
            c.add(tv(text, 13.5f, Palette.sub), mt = 6)
            s.body.add(c, mb = 12)
        }
        section(
            "I forgot my lock",
            "For your safety NEXUS._H has no back door and never stores your lock in readable form, so it cannot be recovered.\n\n" +
                "To start fresh: open Android Settings → Apps → NEXUS._H → Storage → Clear data. This erases the lock, your hidden-app list and NEXUS._H's settings. " +
                "Your other apps and their data are never deleted or changed by NEXUS._H."
        )
        section(
            "I can't find the NEXUS._H icon",
            "1. Swipe down twice from the top of the screen and use the NEXUS._H Quick Settings tile (it opens NEXUS._H even when the icon is hidden).\n" +
                "2. On many phones you can also dial *#*#6394#*#* in the Phone app (some devices block this).\n\n" +
                "NEXUS._H only lets you hide its own icon after the Quick Settings tile has been added, and it restores the icon automatically if you remove that tile."
        )
        section(
            "App lock does not start",
            "• Turn on NEXUS._H under Settings → Accessibility → Installed apps.\n" +
                "• Android 13+: if the switch is greyed out, open Settings → Apps → NEXUS._H, tap ⋮ and choose “Allow restricted settings”, then try again.\n" +
                "• Xiaomi / Redmi / POCO: enable Autostart and set Battery saver to “No restrictions” for NEXUS._H.\n" +
                "• Samsung: Battery → Background usage limits → remove NEXUS._H from sleeping apps.\n" +
                "• OPPO / Realme / vivo / itel: allow Auto-launch / Background activity and exclude NEXUS._H from battery optimisation.\n" +
                "If the service is off, NEXUS._H shows that clearly — it never pretends protection is active."
        )
        section(
            "Limits to know about",
            "• NEXUS._H never replaces your phone's launcher. Hiding apps in NEXUS._H does not remove their icons from Samsung One UI, HyperOS/MIUI, OPPO or other launchers; use your phone maker's own “Hide apps” feature for that.\n" +
                "• Gestures work inside NEXUS._H only, not on your phone's home screen.\n" +
                "• Clean & Exit clears only NEXUS._H's own temporary files and removes NEXUS._H from Recents. It cannot clear other apps."
        )
        section(
            "Uninstalling",
            "NEXUS._H can always be uninstalled from Android Settings → Apps. NEXUS._H does not replace your phone's launcher or use device-admin rights, so nothing blocks uninstalling it."
        )
        setContentView(s.root)
    }
}
