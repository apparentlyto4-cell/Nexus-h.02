package com.nexus.h

import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class AddAppsActivity : SecureActivity() {
    private lateinit var grid: GridLayout
    private lateinit var info: TextView
    private lateinit var addBtn: TextView
    private var all: List<AppEntry> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var query = ""
    private var lockNew = true
    private var reallyHideNew = false
    private lateinit var shizukuCard: LinearLayout
    private val shizukuListener = rikka.shizuku.Shizuku.OnRequestPermissionResultListener { _, grant ->
        runOnUiThread { refreshShizukuCard(); toast(if (grant == android.content.pm.PackageManager.PERMISSION_GRANTED) "Shizuku permission granted" else "Shizuku permission denied") }
    }

    override fun onDestroy() {
        ShizukuManager.removePermissionListener(shizukuListener)
        super.onDestroy()
    }

    override fun buildUi() {
        val s = Screen(this, "Add apps", scroll = false)
        val search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(Palette.sub)
            setTextColor(Palette.text)
            background = glass(14)
            setPadding(dp(14), 0, dp(14), 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun afterTextChanged(e: Editable?) { query = e?.toString()?.trim()?.lowercase() ?: ""; render() }
            })
        }
        s.body.add(search, MATCH, dp(48), mb = 8)
        info = tv("Loading apps…", 14f, Palette.sub).apply { gravity = Gravity.CENTER }
        s.body.add(info, mt = 8)
        val sv = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        grid = GridLayout(this).apply { columnCount = 4 }
        sv.addView(grid)
        s.body.add(sv, MATCH, 0, 1f)

        val bottom = card(12)
        bottom.addView(switchRow("Also lock these apps", "Ask for your lock when they are opened (needs Accessibility).", lockNew) { lockNew = it })
        bottom.addView(divider())
        bottom.addView(switchRow("Really hide the icon (needs Shizuku)", "Removes the icon from every launcher on this phone, not just NEXUS._H's list.", reallyHideNew) { on ->
            if (on && !ShizukuManager.ready()) { reallyHideNew = false; refreshShizukuCard(); toast("Set up Shizuku below first.") }
            else reallyHideNew = on
        })
        shizukuCard = card(12)
        bottom.add(shizukuCard, mt = 8)
        ShizukuManager.addPermissionListener(shizukuListener)
        addBtn = primaryBtn("Add apps") { save() }
        bottom.add(addBtn, mt = 6)
        s.body.add(bottom, mt = 8)
        setContentView(s.root)
        updateButton()
        refreshShizukuCard()

        Bg.executor.execute {
            val r = try { AppRepo.loadAll(applicationContext) } catch (t: Throwable) { null }
            Bg.main.post {
                if (isDestroyed || isFinishing) return@post
                if (r == null) {
                    info.text = "Could not list your apps. Your device may be limiting app visibility."
                    info.setTextColor(Palette.danger)
                } else { all = r; render() }
            }
        }
    }

    private fun render() {
        grid.removeAllViews()
        val hidden = Store.hidden(this)
        val list = all.filter { it.pkg != packageName && !hidden.contains(it.key) && (query.isEmpty() || it.label.lowercase().contains(query)) }
        info.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        if (list.isEmpty()) {
            info.setTextColor(Palette.sub)
            info.text = if (all.isEmpty()) "Loading apps…" else if (query.isNotEmpty()) "No apps match “$query”." else "Every available app is already hidden."
        }
        for (e in list) {
            val t = appTile(e, selected.contains(e.key))
            t.setOnClickListener {
                if (!selected.add(e.key)) selected.remove(e.key)
                render(); updateButton()
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, GridLayout.FILL, 1f)
            ).apply { width = 0; height = WRAP }
            grid.addView(t, lp)
        }
    }

    private fun refreshShizukuCard() {
        shizukuCard.removeAllViews()
        when {
            !ShizukuManager.installed() -> {
                shizukuCard.addView(tv("Shizuku app not found", 14f, Palette.text, true))
                shizukuCard.add(tv("Install the free Shizuku app from the Play Store, start it following its own instructions, then come back here.", 13f, Palette.sub), mt = 4)
            }
            !ShizukuManager.running() -> {
                shizukuCard.addView(tv("Shizuku is not running", 14f, Palette.cyan, true))
                shizukuCard.add(tv("Open the Shizuku app and start its service, then come back here and try again.", 13f, Palette.sub), mt = 4)
            }
            !ShizukuManager.hasPermission() -> {
                shizukuCard.addView(tv("Shizuku permission needed", 14f, Palette.cyan, true))
                shizukuCard.add(tv("Allow NEXUS._H in the Shizuku permission prompt to really hide app icons.", 13f, Palette.sub), mt = 4)
                shizukuCard.add(ghostBtn("Grant Shizuku permission") { ShizukuManager.requestPermission() }, mt = 8)
            }
            else -> shizukuCard.addView(tv("✓ Shizuku ready — icons can be really hidden.", 14f, Palette.ok, true))
        }
    }

    private fun updateButton() {
        addBtn.text = if (selected.isEmpty()) "Select apps to add" else "Add ${selected.size} app${if (selected.size == 1) "" else "s"}"
        addBtn.alpha = if (selected.isEmpty()) 0.5f else 1f
    }

    private fun save() {
        if (selected.isEmpty()) { toast("Tap the apps you want to add first."); return }
        val pkgs = selected.map { it.substringBefore('/') }.toSet()
        Store.setHidden(this, Store.hidden(this) + selected)
        if (lockNew) Store.setLocked(this, Store.locked(this) + selected)
        val n = selected.size
        val lockNote = when {
            !lockNew -> "Not locked: anyone can still open these apps from your phone's launcher."
            Perms.accessibilityEnabled(this) -> "Locked: NEXUS._H will ask for your lock when they are opened."
            else -> "Lock chosen, but Accessibility is OFF, so the lock is not enforced yet (Settings → Permission status)."
        }

        if (reallyHideNew && ShizukuManager.ready()) {
            Store.setReallyHidden(this, Store.reallyHidden(this) + pkgs)
            addBtn.text = "Hiding icons…"
            Bg.executor.execute {
                var ok = true
                for (p in pkgs) ok = ShizukuManager.disable(p) && ok
                Bg.main.post {
                    if (isDestroyed || isFinishing) return@post
                    val hideNote = if (ok) "✓ Icon really hidden from every launcher on this phone."
                    else "Shizuku could not hide one or more of these apps (it may be a protected system app)."
                    finishDialog(n, lockNote + "\n" + hideNote)
                }
            }
        } else {
            val hideNote = if (reallyHideNew) "Icon not really hidden yet: Shizuku is not ready. Turn it on, then use Settings → Hiding & protection to finish."
            else HideInfo.short
            finishDialog(n, lockNote + "\n\n" + hideNote)
        }
    }

    private fun finishDialog(n: Int, note: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle("Added $n app${if (n == 1) "" else "s"} to Hidden apps")
            .setMessage(note)
            .setPositiveButton("OK") { _, _ -> finishInternal() }
            .setNeutralButton("How to hide the icons") { _, _ ->
                android.app.AlertDialog.Builder(this).setTitle("Hide icons in your launcher")
                    .setMessage(HideInfo.launcherSteps())
                    .setPositiveButton("OK") { _, _ -> finishInternal() }
                    .setOnCancelListener { finishInternal() }
                    .show()
            }
            .setOnCancelListener { finishInternal() }
            .show()
    }
}
