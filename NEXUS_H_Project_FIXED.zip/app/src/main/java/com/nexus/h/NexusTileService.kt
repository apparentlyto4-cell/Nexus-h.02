package com.nexus.h

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Quick Settings tile = reliable way back into NEXUS._H even when its launcher icon is hidden.
 * It works with any phone launcher. If the tile is removed, the icon is restored automatically.
 */
class NexusTileService : TileService() {
    override fun onTileAdded() {
        Store.setTileAdded(this, true)
        refresh()
    }

    override fun onTileRemoved() {
        Store.setTileAdded(this, false)
        if (Launcher.isIconHidden(this)) {
            Launcher.setIconHidden(this, false)
            Store.setHideSelf(this, false)
        }
    }

    // Only called while the tile is actually in the panel, so it also confirms "added".
    override fun onStartListening() {
        Store.setTileAdded(this, true)
        refresh()
    }

    override fun onClick() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }

    private fun refresh() {
        qsTile?.let { it.state = Tile.STATE_INACTIVE; it.updateTile() }
    }
}
