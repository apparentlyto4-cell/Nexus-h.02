package com.nexus.h

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView

class HiddenAppsActivity : SecureActivity() {
    private lateinit var grid: GridLayout
    private lateinit var info: TextView
    private var loading = false

    override fun buildUi() {
        val pos = Store.qePos(this)
        val exitIcon = if (pos == 0) iconButton("exit", { QuickExit.run(this) }) else null
        val s = Screen(
            this, "Hidden apps", back = false,
            right = iconButton("gear", { startInternal(Intent(this, SettingsActivity::class.java)) }),
            scroll = true, left = exitIcon
        )
        info = tv("Loading…", 14f, Palette.sub).apply { gravity = Gravity.CENTER }
        s.body.add(info, mt = 8, mb = 8)
        grid = GridLayout(this).apply { columnCount = 4 }
        s.body.add(grid, MATCH, WRAP, mt = 8)

        val frame = FrameLayout(this)
        frame.addView(s.root, FrameLayout.LayoutParams(MATCH, MATCH))
        if (pos != 0) {
            val pill = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                background = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(Palette.violet, Palette.violetDeep)
                ).apply { cornerRadius = dp(26).toFloat() }
                isClickable = true
                pressable()
                setOnClickListener { QuickExit.run(this@HiddenAppsActivity) }
            }
            pill.addView(IconView(this, "exit", Color.WHITE), LinearLayout.LayoutParams(dp(22), dp(22)))
            pill.addView(tv("  CLEAN & EXIT", 14f, Color.WHITE, true))
            val g = when (pos) { 1 -> Gravity.BOTTOM or Gravity.START; 2 -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; else -> Gravity.BOTTOM or Gravity.END }
            frame.addView(pill, FrameLayout.LayoutParams(WRAP, WRAP, g).apply { setMargins(dp(16), dp(16), dp(16), dp(24)) })
        }
        setContentView(frame)
        if (Store.floating(this) && Perms.overlay(this)) QuickExitService.start(this)
        load()
    }

    override fun onSecureResume() {
        load()
        Bg.executor.execute { ShizukuManager.resync(applicationContext) }
    }

    private fun load() {
        if (loading) return
        loading = true
        info.visibility = View.VISIBLE
        info.text = "Loading…"
        val app = applicationContext
        Bg.executor.execute {
            val result = try { AppRepo.loadAll(app) } catch (t: Throwable) { null }
            Bg.main.post {
                loading = false
                if (isDestroyed || isFinishing) return@post
                if (result == null) {
                    info.text = "Could not list your apps. Your device may be limiting app visibility. Try again later."
                    info.setTextColor(Palette.danger)
                } else render(result)
            }
        }
    }

    private fun render(all: List<AppEntry>) {
        val byKey = all.associateBy { it.key }
        val hidden = Store.hidden(this)
        val locked = Store.locked(this)
        val entries = hidden.map { byKey[it] ?: AppRepo.missing(it) }.sortedBy { it.label.lowercase() }
        grid.removeAllViews()
        info.setTextColor(Palette.sub)
        if (entries.isEmpty()) {
            info.visibility = View.VISIBLE
            info.text = "No hidden apps yet.\nTap “Add” to choose the apps you want to keep here."
        } else info.visibility = View.GONE

        fun cell(v: View) {
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, GridLayout.FILL, 1f)
            ).apply { width = 0; height = WRAP }
            grid.addView(v, lp)
        }
        for (e in entries) {
            val t = appTile(e, null, locked.contains(e.key), if (e.available) Palette.text else Palette.sub)
            t.setOnClickListener { open(e) }
            t.setOnLongClickListener { manage(e, locked.contains(e.key)); true }
            cell(t)
        }
        val add = plusTile("Add")
        add.setOnClickListener { startInternal(Intent(this, AddAppsActivity::class.java)) }
        cell(add)
    }

    private fun open(e: AppEntry) {
        if (!e.available) { toast("This app is not available right now."); return }
        AppLockState.allowedPkg = e.pkg
        if (Store.reallyHidden(this).contains(e.pkg) && ShizukuManager.isDisabled(this, e.pkg)) {
            if (!ShizukuManager.ready()) { toast("This app's icon is really hidden and Shizuku is off, so NEXUS._H cannot open it right now. Turn on Shizuku, or enable it from Settings → Apps."); return }
            toast("Unlocking icon…")
            Bg.executor.execute {
                val ok = ShizukuManager.enable(e.pkg)
                Bg.main.post {
                    if (isDestroyed || isFinishing) return@post
                    if (ok) { if (!AppRepo.launch(this, e)) toast("Could not open ${e.label}.") }
                    else toast("Shizuku could not unlock this app's icon.")
                }
            }
        } else {
            if (!AppRepo.launch(this, e)) toast("Could not open ${e.label}.")
        }
    }

    private fun manage(e: AppEntry, isLocked: Boolean) {
        val reallyHidden = Store.reallyHidden(this).contains(e.pkg)
        val items = ArrayList<String>()
        if (e.available) items.add("Open")
        if (e.available) items.add(if (isLocked) "Turn off lock for this app" else "Lock this app when opened")
        if (e.available) items.add(if (reallyHidden) "Show icon again in your launcher" else "Really hide icon (needs Shizuku)")
        items.add("Remove from hidden apps")
        AlertDialog.Builder(this).setTitle(e.label)
            .setItems(items.toTypedArray()) { _, which ->
                when (items[which]) {
                    "Open" -> open(e)
                    "Remove from hidden apps" -> confirmRemove(e)
                    "Turn off lock for this app", "Lock this app when opened" -> {
                        val l = Store.locked(this).toMutableSet()
                        if (isLocked) l.remove(e.key) else l.add(e.key)
                        Store.setLocked(this, l)
                        if (!isLocked && !Perms.accessibilityEnabled(this))
                            toast("Saved. Turn on Accessibility in Settings so locks are enforced.")
                        load()
                    }
                    "Show icon again in your launcher" -> {
                        Store.setReallyHidden(this, Store.reallyHidden(this) - e.pkg)
                        Bg.executor.execute {
                            val ok = ShizukuManager.ready() && ShizukuManager.enable(e.pkg)
                            Bg.main.post { toast(if (ok) "Icon restored." else "Could not restore the icon automatically. Enable it from Settings → Apps → ${e.label}."); load() }
                        }
                    }
                    else -> {
                        if (!ShizukuManager.ready()) { toast("Set up Shizuku first, from the Add apps screen or Settings → Hiding & protection."); return@setItems }
                        Store.setReallyHidden(this, Store.reallyHidden(this) + e.pkg)
                        Bg.executor.execute {
                            val ok = ShizukuManager.disable(e.pkg)
                            Bg.main.post { toast(if (ok) "✓ Icon really hidden." else "Shizuku could not hide this app."); load() }
                        }
                    }
                }
            }.show()
    }

    private fun confirmRemove(e: AppEntry) {
        AlertDialog.Builder(this).setTitle("Remove ${e.label}?")
            .setMessage("It will no longer be listed here and its NEXUS._H lock is removed. The app itself is not changed or deleted.")
            .setPositiveButton("Remove") { _, _ ->
                Store.setHidden(this, Store.hidden(this) - e.key)
                Store.setLocked(this, Store.locked(this) - e.key)
                if (Store.reallyHidden(this).contains(e.pkg)) {
                    Store.setReallyHidden(this, Store.reallyHidden(this) - e.pkg)
                    Bg.executor.execute { if (ShizukuManager.ready()) ShizukuManager.enable(e.pkg) }
                }
                load()
            }
            .setNegativeButton("Cancel", null).show()
    }
}
