package com.nexus.h

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

/** Optional floating "CLEAN & EXIT" button. Needs the "Display over other apps" permission. */
class QuickExitService : Service() {
    private var wm: WindowManager? = null
    private var view: View? = null

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { stopSelf() }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startFg()
        if (!Perms.overlay(this) || !Store.floating(this)) { stopSelf(); return START_NOT_STICKY }
        if (view == null) showButton()
        try { registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF)) } catch (_: Throwable) {}
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("quick_exit", getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, QuickExitService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "quick_exit")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("NEXUS._H Quick Exit is ready")
            .setContentText("Tap the floating button to leave instantly.")
            .setOngoing(true)
            .addAction(R.drawable.ic_notif, "Hide button", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun showButton() {
        val ctx = this
        val btn = ctx.tv("  CLEAN & EXIT  ", 13f, android.graphics.Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Palette.violet, Palette.violetDeep)
            ).apply { cornerRadius = ctx.dp(24).toFloat() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val dm = resources.displayMetrics
            when (Store.qePos(ctx)) {
                0 -> { x = ctx.dp(12); y = ctx.dp(70) }
                1 -> { x = ctx.dp(12); y = dm.heightPixels - ctx.dp(170) }
                2 -> { x = dm.widthPixels / 2 - ctx.dp(65); y = dm.heightPixels - ctx.dp(170) }
                else -> { x = dm.widthPixels - ctx.dp(150); y = dm.heightPixels - ctx.dp(170) }
            }
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        btn.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > ctx.dp(8) || abs(dy) > ctx.dp(8)) moved = true
                    if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); try { wm?.updateViewLayout(btn, lp) } catch (_: Throwable) {} }
                }
                MotionEvent.ACTION_UP -> if (!moved) QuickExit.run(applicationContext)
            }
            true
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try { wm?.addView(btn, lp); view = btn } catch (_: Throwable) { stopSelf() }
    }

    override fun onDestroy() {
        try { view?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        view = null
        try { unregisterReceiver(screenOff) } catch (_: Throwable) {}
        running = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.nexus.h.STOP_QUICK_EXIT"
        @Volatile var running = false

        fun start(c: Context) {
            if (!Store.floating(c) || !Perms.overlay(c)) return
            if (running) return
            running = true
            try { c.startForegroundService(Intent(c, QuickExitService::class.java)) } catch (_: Throwable) { running = false }
        }

        fun stop(c: Context) {
            running = false
            try { c.stopService(Intent(c, QuickExitService::class.java)) } catch (_: Throwable) {}
        }
    }
}
