package com.nexus.h

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

private fun Activity.lockedScroll(panel: android.view.View): ScrollView {
    val sv = ScrollView(this).apply { isFillViewport = true }
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(20), dp(24), dp(20), dp(24))
    }
    box.add(panel, MATCH, WRAP)
    sv.addView(box, FrameLayout.LayoutParams(MATCH, MATCH))
    return sv
}

/** Unlock screen used before Hidden Apps / Settings. Returns RESULT_OK when verified. */
class AuthActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        if (!Credentials.isSet(this)) { setResult(RESULT_CANCELED); finish(); return }
        val panel = LockScreenView(
            this, "Unlock NEXUS._H", "Verify your identity to continue.", true,
            onVerified = {
                Session.unlock()
                setResult(RESULT_OK)
                finish()
            },
            onForgot = { startActivity(Intent(this, RecoveryActivity::class.java)) }
        )
        setContentView(lockedScroll(panel))
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        setResult(RESULT_CANCELED)
        finish()
    }
}

/**
 * Lock screen shown over a protected app. Runs in its own task, so finishing it
 * reveals the protected app (success) or we send the user Home (cancel).
 */
class AppLockActivity : Activity() {
    private var pkg: String? = null
    private var success = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        show(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        success = false
        show(intent)
    }

    private fun show(i: Intent) {
        pkg = i.getStringExtra("pkg")
        AppLockState.overlayShowing = true
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg ?: "", 0)).toString()
        } catch (_: Throwable) { "This app" }
        val panel = LockScreenView(
            this, "$label is locked", "Enter your NEXUS._H lock to open it.", true,
            onVerified = {
                success = true
                AppLockState.allowedPkg = pkg
                AppLockState.overlayShowing = false
                finish()
            },
            onForgot = null
        )
        setContentView(lockedScroll(panel))
    }

    private fun goHome() {
        AppLockState.overlayShowing = false
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
        }
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = goHome()

    override fun onStop() {
        super.onStop()
        // If the user leaves without unlocking (Home, Recents, screen off), drop this screen.
        if (!success) { AppLockState.overlayShowing = false; finish() }
    }

    override fun onDestroy() {
        AppLockState.overlayShowing = false
        super.onDestroy()
    }
}
