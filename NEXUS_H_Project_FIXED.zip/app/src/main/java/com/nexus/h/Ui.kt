package com.nexus.h

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object Palette {
    val bg0 = Color.parseColor("#06060C")
    val bg1 = Color.parseColor("#0E0B24")
    val violet = Color.parseColor("#8B5CF6")
    val violetDeep = Color.parseColor("#6D28D9")
    val purple = Color.parseColor("#C084FC")
    val cyan = Color.parseColor("#22D3EE")
    val text = Color.parseColor("#F5F5FA")
    val sub = Color.parseColor("#A3A3B8")
    val glass = Color.parseColor("#1AFFFFFF")
    val glassStrong = Color.parseColor("#2AFFFFFF")
    val glassStroke = Color.parseColor("#26FFFFFF")
    val danger = Color.parseColor("#F87171")
    val ok = Color.parseColor("#34D399")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun Context.glass(radius: Int = 20, fill: Int = Palette.glass, stroke: Int = Palette.glassStroke): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

fun Context.tv(text: CharSequence, sp: Float = 15f, color: Int = Palette.text, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }

fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        false
    }
}

fun Context.primaryBtn(text: String, onClick: () -> Unit): TextView =
    tv(text, 16f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        minHeight = dp(52)
        setPadding(dp(20), dp(12), dp(20), dp(12))
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Palette.violet, Palette.violetDeep))
            .apply { cornerRadius = dp(16).toFloat() }
        isClickable = true
        isFocusable = true
        pressable()
        setOnClickListener { onClick() }
    }

fun Context.ghostBtn(text: String, onClick: () -> Unit): TextView =
    tv(text, 15f, Palette.text, true).apply {
        gravity = Gravity.CENTER
        minHeight = dp(48)
        setPadding(dp(18), dp(10), dp(18), dp(10))
        background = glass(16)
        isClickable = true
        isFocusable = true
        pressable()
        setOnClickListener { onClick() }
    }

fun Context.linkBtn(text: String, onClick: () -> Unit): TextView =
    tv(text, 14f, Palette.purple, true).apply {
        gravity = Gravity.CENTER
        minHeight = dp(44)
        setPadding(dp(16), dp(8), dp(16), dp(8))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

fun Context.card(pad: Int = 16): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = glass(20)
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
}

fun Context.chip(text: String, selected: Boolean, onClick: () -> Unit): TextView =
    tv(text, 13f, if (selected) Color.WHITE else Palette.sub, true).apply {
        gravity = Gravity.CENTER
        minHeight = dp(44)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = if (selected)
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Palette.violet, Palette.violetDeep))
                .apply { cornerRadius = dp(14).toFloat() }
        else glass(14)
        isClickable = true
        setOnClickListener { onClick() }
    }

fun LinearLayout.add(
    v: View, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f,
    ml: Int = 0, mt: Int = 0, mr: Int = 0, mb: Int = 0
): View {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(context.dp(ml), context.dp(mt), context.dp(mr), context.dp(mb))
    addView(v, p)
    return v
}

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

fun Context.circleLogo(sizeDp: Int): ImageView = ImageView(this).apply {
    setImageResource(R.drawable.logo_circle)
    scaleType = ImageView.ScaleType.FIT_CENTER
    layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
}

fun Context.switchRow(title: String, sub: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit): LinearLayout {
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        minimumHeight = dp(56)
        setPadding(0, dp(6), 0, dp(6))
    }
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    col.addView(tv(title, 15f, if (enabled) Palette.text else Palette.sub, true))
    if (sub.isNotEmpty()) col.addView(tv(sub, 12.5f, Palette.sub))
    row.add(col, 0, WRAP, 1f, mr = 12)
    val sw = android.widget.Switch(this).apply {
        isChecked = checked
        isEnabled = enabled
        setOnCheckedChangeListener { _, b -> onChange(b) }
    }
    row.addView(sw)
    return row
}

fun Context.navRow(title: String, sub: String, onClick: () -> Unit): LinearLayout {
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        minimumHeight = dp(56)
        setPadding(0, dp(6), 0, dp(6))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    col.addView(tv(title, 15f, Palette.text, true))
    if (sub.isNotEmpty()) col.addView(tv(sub, 12.5f, Palette.sub))
    row.add(col, 0, WRAP, 1f, mr = 8)
    row.addView(tv("›", 22f, Palette.sub))
    return row
}

fun Context.divider(): View = View(this).apply {
    setBackgroundColor(Palette.glassStroke)
    layoutParams = LinearLayout.LayoutParams(MATCH, 1).apply { setMargins(0, dp(2), 0, dp(2)) }
}

/** Small drawn icons so we do not depend on icon fonts or vector path data. */
class IconView(ctx: Context, private val kind: String, private val tint: Int = Palette.text) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = tint
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = minOf(w, h)
        p.strokeWidth = s * 0.085f
        p.style = Paint.Style.STROKE
        p.color = tint
        val cx = w / 2; val cy = h / 2
        when (kind) {
            "back" -> {
                c.drawLine(cx + s * .12f, cy - s * .22f, cx - s * .12f, cy, p)
                c.drawLine(cx - s * .12f, cy, cx + s * .12f, cy + s * .22f, p)
            }
            "plus" -> {
                c.drawLine(cx - s * .2f, cy, cx + s * .2f, cy, p)
                c.drawLine(cx, cy - s * .2f, cx, cy + s * .2f, p)
            }
            "exit" -> {
                val r = RectF(cx - s * .26f, cy - s * .26f, cx + s * .06f, cy + s * .26f)
                c.drawLine(r.right, r.top, r.left, r.top, p)
                c.drawLine(r.left, r.top, r.left, r.bottom, p)
                c.drawLine(r.left, r.bottom, r.right, r.bottom, p)
                c.drawLine(cx - s * .04f, cy, cx + s * .28f, cy, p)
                c.drawLine(cx + s * .16f, cy - s * .11f, cx + s * .28f, cy, p)
                c.drawLine(cx + s * .16f, cy + s * .11f, cx + s * .28f, cy, p)
            }
            "gear" -> {
                p.style = Paint.Style.STROKE
                c.drawCircle(cx, cy, s * .17f, p)
                p.style = Paint.Style.FILL
                for (i in 0 until 8) {
                    c.save()
                    c.rotate(i * 45f, cx, cy)
                    c.drawRoundRect(cx - s * .05f, cy - s * .33f, cx + s * .05f, cy - s * .22f, s * .02f, s * .02f, p)
                    c.restore()
                }
                p.style = Paint.Style.STROKE
                c.drawCircle(cx, cy, s * .24f, p)
            }
            "check" -> {
                c.drawLine(cx - s * .2f, cy + s * .02f, cx - s * .06f, cy + s * .16f, p)
                c.drawLine(cx - s * .06f, cy + s * .16f, cx + s * .22f, cy - s * .16f, p)
            }
            "grid" -> {
                p.style = Paint.Style.FILL
                for (i in 0..2) for (j in 0..2)
                    c.drawCircle(cx + (i - 1) * s * .22f, cy + (j - 1) * s * .22f, s * .055f, p)
            }
            "search" -> {
                c.drawCircle(cx - s * .05f, cy - s * .05f, s * .17f, p)
                c.drawLine(cx + s * .08f, cy + s * .08f, cx + s * .24f, cy + s * .24f, p)
            }
        }
    }
}

fun Context.iconButton(kind: String, onClick: () -> Unit, tint: Int = Palette.text): FrameLayout =
    FrameLayout(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        background = glass(14)
        isClickable = true
        isFocusable = true
        pressable()
        setOnClickListener { onClick() }
        addView(IconView(context, kind, tint), FrameLayout.LayoutParams(MATCH, MATCH))
    }

fun Context.roundedIcon(icon: Drawable, sizeDp: Int): ImageView = ImageView(this).apply {
    setImageDrawable(icon)
    scaleType = ImageView.ScaleType.FIT_CENTER
    layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
}

/** Standard screen: header row + scrolling body. */
class Screen(
    val act: Activity,
    title: String,
    back: Boolean = true,
    right: View? = null,
    onBack: (() -> Unit)? = null,
    scroll: Boolean = true,
    left: View? = null
) {
    val root = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(act.dp(16), act.dp(12), act.dp(16), act.dp(12))
    }
    val body = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }

    init {
        val header = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (left != null) header.addView(left)
        else if (back) header.addView(act.iconButton("back", { (onBack ?: { act.onBackPressed() })() }))
        else header.addView(View(act), LinearLayout.LayoutParams(act.dp(48), act.dp(48)))
        val t = act.tv(title, 19f, Palette.text, true).apply { gravity = Gravity.CENTER; maxLines = 1 }
        header.add(t, 0, WRAP, 1f, ml = 8, mr = 8)
        if (right != null) header.addView(right) else header.addView(View(act), LinearLayout.LayoutParams(act.dp(48), act.dp(48)))
        root.add(header, mb = 12)
        if (scroll) {
            val sv = ScrollView(act).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
            sv.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
            root.add(sv, MATCH, 0, 1f)
        } else {
            root.add(body, MATCH, 0, 1f)
        }
    }
}
