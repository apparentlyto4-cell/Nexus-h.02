package com.nexus.h

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Real icon hiding, backed by Shizuku (https://shizuku.rikka.app), an on-device permission
 * broker the user installs and turns on separately. NEXUS._H never talks to Shizuku over the
 * network — only via Android's own binder IPC, the same path Shizuku offers every app that uses it.
 *
 * What this actually does: runs `pm disable-user` / `pm enable` for one package at a time,
 * exactly what Settings > Apps > Disable does for system apps. It cannot touch apps Android
 * itself refuses to disable (NEXUS._H itself, and some core system apps).
 *
 * Note on API surface: Shizuku's public API stopped exposing a shell-exec call after v11;
 * every Shizuku-integrated app that still shells out does it via reflection onto the
 * (still server-side present) Shizuku.newProcess method, which is what REFLECT_EXEC below does.
 * This was written from the documented Shizuku API and has not been exercised against a live
 * Shizuku server in this environment — verify on-device, and tell us the exact error if the
 * reflection call fails so we can adjust it.
 */
object ShizukuManager {
    const val REQUEST_CODE = 9100

    fun installed(): Boolean = try {
        Class.forName("rikka.shizuku.Shizuku")
        true
    } catch (t: Throwable) {
        false
    }

    fun running(): Boolean = try {
        installed() && Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    /** Ready to actually hide/unhide apps right now. */
    fun ready(): Boolean = hasPermission()

    fun requestPermission() {
        try {
            if (running() && !Shizuku.isPreV11()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (t: Throwable) {
        }
    }

    fun addPermissionListener(l: Shizuku.OnRequestPermissionResultListener) = try {
        Shizuku.addRequestPermissionResultListener(l)
    } catch (t: Throwable) {
    }

    fun removePermissionListener(l: Shizuku.OnRequestPermissionResultListener) = try {
        Shizuku.removeRequestPermissionResultListener(l)
    } catch (t: Throwable) {
    }

    fun isDisabled(c: Context, pkg: String): Boolean = try {
        val flags = PackageManager.MATCH_DISABLED_COMPONENTS
        val ai = c.packageManager.getApplicationInfo(pkg, flags)
        !ai.enabled
    } catch (t: Throwable) {
        false
    }

    /** Blocking. Call off the main thread (Bg.executor). */
    fun disable(pkg: String): Boolean = exec("pm disable-user --user 0 $pkg")

    /** Blocking. Call off the main thread (Bg.executor). */
    fun enable(pkg: String): Boolean = exec("pm enable $pkg")

    /** Re-applies every package the user wants really hidden. Safe no-op if Shizuku is not ready. */
    fun resync(c: Context) {
        if (!ready()) return
        val want = Store.reallyHidden(c)
        for (pkg in want) if (!isDisabled(c, pkg)) disable(pkg)
    }

    private fun exec(cmd: String): Boolean {
        if (!ready()) return false
        return try {
            val m = Shizuku::class.java.getMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val process = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as? Process ?: return false
            val code = process.waitFor()
            code == 0
        } catch (t: Throwable) {
            false
        }
    }
}
