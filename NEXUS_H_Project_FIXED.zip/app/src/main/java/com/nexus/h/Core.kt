package com.nexus.h

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.Executors
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object LockType {
    const val PATTERN = "pattern"
    const val PIN = "pin"
    const val PASSWORD = "password"
    fun title(t: String?) = when (t) {
        PATTERN -> "Pattern"
        PIN -> "PIN"
        PASSWORD -> "Password"
        else -> "Not set"
    }
}

/** Non-secret settings. Credentials are NOT stored here. */
object Store {
    private fun p(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("nexus_h_prefs", Context.MODE_PRIVATE)

    fun onboarded(c: Context) = p(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context, v: Boolean) = p(c).edit().putBoolean("onboarded", v).apply()

    fun hidden(c: Context): Set<String> = HashSet(p(c).getStringSet("hidden", emptySet()) ?: emptySet())
    fun setHidden(c: Context, s: Set<String>) { p(c).edit().putStringSet("hidden", HashSet(s)).commit() }

    fun locked(c: Context): Set<String> = HashSet(p(c).getStringSet("locked", emptySet()) ?: emptySet())
    fun setLocked(c: Context, s: Set<String>) { p(c).edit().putStringSet("locked", HashSet(s)).commit() }

    fun lockedPackages(c: Context): Set<String> = locked(c).map { it.substringBefore('/') }.toSet()

    fun gesture(c: Context): Gesture = Gesture.byId(p(c).getString("gesture", null))
    fun setGesture(c: Context, g: Gesture) = p(c).edit().putString("gesture", g.id).apply()

    /** 0 top-left, 1 bottom-left, 2 bottom-center, 3 bottom-right */
    fun qePos(c: Context) = p(c).getInt("qe_pos", 0)
    fun setQePos(c: Context, v: Int) = p(c).edit().putInt("qe_pos", v).apply()

    fun floating(c: Context) = p(c).getBoolean("floating", false)
    fun setFloating(c: Context, v: Boolean) = p(c).edit().putBoolean("floating", v).apply()

    fun lockEnforce(c: Context) = p(c).getBoolean("lock_enforce", true)
    fun setLockEnforce(c: Context, v: Boolean) = p(c).edit().putBoolean("lock_enforce", v).apply()

    fun hideSelf(c: Context) = p(c).getBoolean("hide_self", false)
    fun setHideSelf(c: Context, v: Boolean) = p(c).edit().putBoolean("hide_self", v).apply()

    fun dock(c: Context): List<String> =
        (p(c).getString("dock", "") ?: "").split("|").filter { it.isNotEmpty() }
    fun setDock(c: Context, l: List<String>) = p(c).edit().putString("dock", l.joinToString("|")).apply()

    /** True while the NEXUS._H Quick Settings tile is in the user's panel (the verified re-entry path). */
    fun tileAdded(c: Context) = p(c).getBoolean("tile_added", false)
    fun setTileAdded(c: Context, v: Boolean) = p(c).edit().putBoolean("tile_added", v).apply()

    /** Packages the user wants truly hidden from every launcher (needs Shizuku to enforce). */
    fun reallyHidden(c: Context): Set<String> = HashSet(p(c).getStringSet("really_hidden", emptySet()) ?: emptySet())
    fun setReallyHidden(c: Context, s: Set<String>) { p(c).edit().putStringSet("really_hidden", HashSet(s)).commit() }

    fun homeGesture(c: Context) = p(c).getBoolean("home_gesture", false)
    fun setHomeGesture(c: Context, v: Boolean) = p(c).edit().putBoolean("home_gesture", v).apply()
    fun handlePos(c: Context) = p(c).getInt("handle_pos", 3)
    fun setHandlePos(c: Context, v: Int) = p(c).edit().putInt("handle_pos", v).apply()

    fun lastClean(c: Context): String = p(c).getString("last_clean", "") ?: ""
    fun setLastClean(c: Context, s: String) = p(c).edit().putString("last_clean", s).apply()
}

/** In-memory unlock state. Lost when the process dies, which means "locked". */
object Session {
    @Volatile var unlocked = false
    @Volatile var internalNav = false
    fun unlock() { unlocked = true }
    fun lock() { unlocked = false }
}

/** Package the user has just authenticated for via the app-lock screen. */
object AppLockState {
    @Volatile var allowedPkg: String? = null
    @Volatile var overlayShowing = false
}

object Bg {
    val executor = Executors.newSingleThreadExecutor()
    val main = Handler(Looper.getMainLooper())
}

/**
 * Salted PBKDF2 hash, additionally sealed with an HMAC key that lives in Android Keystore.
 * The secret itself is never stored or logged.
 */
object Credentials {
    private const val ALIAS = "nexus_h_hmac_v1"
    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("nexus_h_sec", Context.MODE_PRIVATE)

    fun type(c: Context): String? = sp(c).getString("type", null)
    fun isSet(c: Context): Boolean = sp(c).contains("hash") && sp(c).contains("salt") && type(c) != null

    fun save(c: Context, type: String, secret: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val derived = pbkdf2(secret, salt)
        var sealed = true
        val out = try { hmac(derived) } catch (e: Exception) { sealed = false; derived }
        // One atomic write: type + hash + salt always change together.
        sp(c).edit()
            .putString("type", type)
            .putString("hash", b64(out))
            .putString("salt", b64(salt))
            .putBoolean("sealed", sealed)
            .putInt("fails", 0)
            .putLong("until", 0L)
            .commit()
    }

    fun verify(c: Context, secret: String): Boolean {
        return try {
            val h = sp(c).getString("hash", null) ?: return false
            val s = sp(c).getString("salt", null) ?: return false
            val sealed = sp(c).getBoolean("sealed", false)
            val derived = pbkdf2(secret, Base64.decode(s, Base64.NO_WRAP))
            val out = if (sealed) hmac(derived) else derived
            MessageDigest.isEqual(out, Base64.decode(h, Base64.NO_WRAP))
        } catch (e: Exception) {
            false
        }
    }

    fun lockoutRemainingMs(c: Context): Long =
        maxOf(0L, sp(c).getLong("until", 0L) - System.currentTimeMillis())

    /** Returns lockout duration in ms (0 when still allowed to try). */
    fun registerFail(c: Context): Long {
        val fails = sp(c).getInt("fails", 0) + 1
        var wait = 0L
        if (fails >= 5) wait = 30_000L * (1L shl minOf(fails - 5, 4))
        sp(c).edit().putInt("fails", fails).putLong("until", if (wait > 0) System.currentTimeMillis() + wait else 0L).apply()
        return wait
    }

    fun failsLeftBeforeLockout(c: Context): Int = maxOf(0, 5 - sp(c).getInt("fails", 0))
    fun resetFails(c: Context) = sp(c).edit().putInt("fails", 0).putLong("until", 0L).apply()

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)

    private fun pbkdf2(secret: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(secret.toCharArray(), salt, 100_000, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, "AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN).build())
        return kg.generateKey()
    }

    private fun hmac(data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(key())
        return mac.doFinal(data)
    }
}

/** Cleans ONLY NEXUS._H's own disposable cache. Never touches credentials or settings. */
object Cleaner {
    fun cleanAsync(c: Context) {
        val app = c.applicationContext
        Thread {
            var freed = 0L
            try {
                freed += wipeChildren(app.cacheDir)
                app.externalCacheDir?.let { freed += wipeChildren(it) }
            } catch (_: Throwable) {
            }
            Store.setLastClean(app, "${System.currentTimeMillis()}|$freed")
        }.start()
    }

    private fun wipeChildren(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0
        var total = 0L
        dir.listFiles()?.forEach { f ->
            total += size(f)
            f.deleteRecursively()
        }
        return total
    }

    private fun size(f: File): Long =
        if (f.isDirectory) (f.listFiles()?.sumOf { size(it) } ?: 0L) else f.length()
}

object QuickExit {
    /** Starts Home right away; cleanup runs in the background and is best-effort. */
    fun run(c: Context) {
        Session.lock()
        AppLockState.allowedPkg = null
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(home)
        } catch (_: Throwable) {
        }
        Cleaner.cleanAsync(c)
        removeOwnTasks(c)
        QuickExitService.stop(c)
        Bg.executor.execute { ShizukuManager.resync(c.applicationContext) }
    }

    /** Removes NEXUS._H's own tasks from Recents. Own app only. */
    private fun removeOwnTasks(c: Context) {
        try {
            val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            for (t in am.appTasks) {
                t.finishAndRemoveTask()
            }
        } catch (_: Throwable) {
        }
    }
}

object Launcher {
    private fun alias(c: Context) = ComponentName(c, "com.nexus.h.LauncherAlias")

    fun isIconHidden(c: Context): Boolean =
        c.packageManager.getComponentEnabledSetting(alias(c)) == PackageManager.COMPONENT_ENABLED_STATE_DISABLED

    fun setIconHidden(c: Context, hidden: Boolean) {
        c.packageManager.setComponentEnabledSetting(
            alias(c),
            if (hidden) PackageManager.COMPONENT_ENABLED_STATE_DISABLED else PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
    }

    /** Safety net: never leave the icon hidden unless the Quick Settings tile (re-entry) is in place. */
    fun selfHeal(c: Context) {
        if (isIconHidden(c) && !Store.tileAdded(c)) {
            setIconHidden(c, false)
            Store.setHideSelf(c, false)
        }
    }
}
